document.write('<marquee>Selamat datang di Website Pemerintah Daerah Kota XYZ! Welcome Bro Sis ...!</marquee>');
